﻿namespace UserRegistration.wwwroot
{
    public class images
    {
    }
}
